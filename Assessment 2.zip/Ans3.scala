/*Problem 3: Create a Scala program to prompt customers for their name and age.
 The format for the name and age labels should be in bold. And, the name literal should be underlined.*/
 
 object Ans3
{
	def main(args: Array[String])
	{
	import scala.io.StdIn._
    val name = readLine("Enter your name: ")
    println("Enter your age: ")
    val age = readInt()
    println(Console.BOLD)
    print("Name: ")
    print(Console.UNDERLINED)
    print(name)
    println(Console.BOLD)
    print("Age: ")
    print(Console.RESET)
    print(age)

	}
	}
 

