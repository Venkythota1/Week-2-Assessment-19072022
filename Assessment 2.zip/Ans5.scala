/*Problem 5: Create a Scala program to calculate the total cost for a customer who is buying 10 Glazed donuts. You can assume that the price of each Glazed donut item is at $2.50. 
Notice the format of the $25.00 total cost literal, 
which is essentially at 2 decimal places.*/

object Ans5
{
	def main(args: Array[String])
	{
	 val glazedDonut = "Glazed Donut"
    val unitPrice = 2.50
    val qtyPurchased = 10
    val totalCost = qtyPurchased * unitPrice

    println(f"""Total cost of $qtyPurchased $glazedDonut${if (qtyPurchased > 1) "s" else ""} = $$$totalCost%1.2f""")
	}
	}